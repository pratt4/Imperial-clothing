import 'regenerator-runtime/runtime'
import React, { useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faMicrophone, faStop } from '@fortawesome/free-solid-svg-icons';
import SpeechRecognition, { useSpeechRecognition } from 'react-speech-recognition';
import styled from 'styled-components';

// Icon button for microphone icon
const IconButton = styled.div`
  display: flex;
  align-items: center;
  cursor: pointer;
  margin: 0 10px;
  padding: 5px;
  border-radius: 50%;
  transition: background-color 0.3s ease;

  &:hover {
    background-color: #555;
  }
`;

// Dialog box for speech recognition results
const SpeechRecognitionDialog = styled.div`
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background-color: white;
  padding: 20px;
  border: 1px solid black;
  display: ${props => props.open ? 'block' : 'none'};
`;

const SpeechRecognitionButton = () => {
  // State for the dialog box
  const [dialogOpen, setDialogOpen] = useState(false);

  const { transcript, listening } = useSpeechRecognition();

  // Start speech recognition
  const startSpeechRecognition = () => {
    if (!listening) {
      SpeechRecognition.startListening();
      setDialogOpen(true);
    }
  };

  // Stop speech recognition
  const stopSpeechRecognition = () => {
    if (listening) {
      SpeechRecognition.stopListening();
      setDialogOpen(false);
    }
  };

  return (
    <>
      <IconButton onClick={startSpeechRecognition}>
        <FontAwesomeIcon icon={faMicrophone} />
      </IconButton>
      {listening && <IconButton onClick={stopSpeechRecognition}>
        <FontAwesomeIcon icon={faStop} />
      </IconButton>}
      <SpeechRecognitionDialog open={dialogOpen}>
        {transcript}
      </SpeechRecognitionDialog>
    </>
  );
};

export default SpeechRecognitionButton;
